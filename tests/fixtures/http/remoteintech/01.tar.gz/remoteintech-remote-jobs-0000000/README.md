# remote-jobs (synthetic)
