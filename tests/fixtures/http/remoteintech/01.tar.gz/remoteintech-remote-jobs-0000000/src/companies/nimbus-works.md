---
slug: nimbus-works
title: Nimbus Works
website: https://nimbusworks.example/
careers_url: https://nimbusworks.example/careers
region: americas-europe
remote_policy: fully-remote
addedAt: 2026-01-01
---

## Company blurb

Nimbus Works is a synthetic company.
