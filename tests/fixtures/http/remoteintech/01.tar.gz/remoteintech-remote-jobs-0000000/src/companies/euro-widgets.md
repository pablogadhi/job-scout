---
slug: euro-widgets
title: Euro Widgets
website: https://eurowidgets.example/
careers_url: https://jobs.lever.co/eurowidgets
region: europe
remote_policy: fully-remote
addedAt: 2026-01-01
---

## Company blurb

Euro Widgets is a synthetic company.
