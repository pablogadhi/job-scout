---
slug: tikal-soft
title: Tikal Soft
website: https://www.tikalsoft.example/
region: worldwide
remote_policy: fully-remote
addedAt: 2026-01-01
---

## Company blurb

Tikal Soft is a synthetic company.
