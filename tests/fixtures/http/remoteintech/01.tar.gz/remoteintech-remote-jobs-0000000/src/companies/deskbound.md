---
slug: deskbound
title: Deskbound
website: https://deskbound.example/
region: americas
remote_policy: hybrid
addedAt: 2026-01-01
---

## Company blurb

Deskbound is a synthetic company.
